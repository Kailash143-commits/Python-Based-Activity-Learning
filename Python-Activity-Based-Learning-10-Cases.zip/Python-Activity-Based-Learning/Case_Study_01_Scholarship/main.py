# Case Study 1: University Scholarship Allocation
# Sample policy: aggregate >= 80, each subject >= 70, attendance >= 75,
# family income <= 300000. Rank eligible students by aggregate, then attendance.

students = [
    ("Asha", 88, [85, 90, 89], 92, 250000),
    ("Balu", 84, [78, 82, 80], 88, 280000),
    ("Charan", 91, [90, 68, 95], 95, 200000),
    ("Divya", 84, [80, 85, 87], 91, 290000),
    ("Esha", 79, [80, 82, 81], 90, 180000),
]

eligible = []
for name, aggregate, subjects, attendance, income in students:
    if (aggregate >= 80 and min(subjects) >= 70
            and attendance >= 75 and income <= 300000):
        eligible.append((name, aggregate, attendance, income))

eligible.sort(key=lambda student: (student[1], student[2]), reverse=True)

print("ELIGIBLE SCHOLARSHIP CANDIDATES")
if eligible:
    for rank, student in enumerate(eligible, start=1):
        name, aggregate, attendance, income = student
        print(f"{rank}. {name} - Aggregate: {aggregate}%, Attendance: {attendance}%, Income: Rs.{income}")
else:
    print("No eligible candidates.")
