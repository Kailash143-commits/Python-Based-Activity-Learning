# Case Study 6: Student Timetable Conflict Detection
# Each tuple: (course, day, start_hour, end_hour, room)

classes = [
    ("Python", "Monday", 9, 10, "Lab-1"),
    ("Maths", "Monday", 10, 11, "Room-2"),
    ("Physics", "Monday", 9, 10, "Room-3"),
    ("English", "Tuesday", 9, 10, "Room-1"),
]

print("TIMETABLE CONFLICT CHECK")
conflicts = 0
for i in range(len(classes)):
    for j in range(i + 1, len(classes)):
        c1 = classes[i]
        c2 = classes[j]
        same_day = c1[1] == c2[1]
        overlap = c1[2] < c2[3] and c2[2] < c1[3]
        same_room = c1[4] == c2[4]
        if same_day and overlap:
            if same_room:
                print(f"Room conflict: {c1[0]} and {c2[0]} in {c1[4]}")
            else:
                print(f"Time conflict: {c1[0]} and {c2[0]} overlap on {c1[1]}")
            conflicts += 1

if conflicts == 0:
    print("No conflicts found.")
else:
    print(f"Total conflicts: {conflicts}")
