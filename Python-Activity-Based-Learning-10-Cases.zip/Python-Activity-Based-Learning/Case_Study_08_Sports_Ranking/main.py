# Case Study 8: Sports Tournament Ranking System
# Points policy: win = 3, draw = 1, loss = 0.
# Results are given as (team, wins, draws, goal_difference).

teams = [
    ("Tigers", 3, 1, 7),
    ("Eagles", 3, 1, 5),
    ("Lions", 2, 2, 4),
    ("Bears", 1, 1, -2),
]

ranked = []
for name, wins, draws, goal_difference in teams:
    points = wins * 3 + draws
    ranked.append((name, points, goal_difference))

ranked.sort(key=lambda team: (team[1], team[2]), reverse=True)

print("TOURNAMENT RANKINGS")
for rank, (name, points, gd) in enumerate(ranked, start=1):
    print(f"{rank}. {name} - Points: {points}, Goal difference: {gd}")
