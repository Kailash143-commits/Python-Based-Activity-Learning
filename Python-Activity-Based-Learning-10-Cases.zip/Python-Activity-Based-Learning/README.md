# Python Activity-Based Learning

Selected 10 case studies from the provided list of 100.

## Case studies
1. University Scholarship Allocation
2. Progressive Electricity Billing
3. Retail Billing with Multiple Discount Rules
4. Examination Result and Grace-Mark Validation
5. Warehouse Inventory Reconciliation
6. Student Timetable Conflict Detection
7. Student Marks Matrix Analysis
8. Sports Tournament Ranking System
9. Student Academic Risk Classification
10. E-Commerce Order Processing and Reconciliation

## How to run
1. Install Python 3.
2. Open a case-study folder in PyCharm or a terminal.
3. Run `python main.py`.
4. Compare the console output with `sample_output.txt`.
5. Capture a screenshot of your own run for the final report.

## Important
The policies, thresholds, and records used are sample assumptions for demonstrating the programs. Check the case-study instructions supplied by your faculty and change these assumptions if required. Add your own name, roll number, branch, and section before submitting.
