# Case Study 9: Student Academic Risk Classification
# Sample policy: high risk if attendance < 65 or average marks < 40;
# medium risk if attendance < 75 or average marks < 50; otherwise low risk.

students = [
    ("Asha", [65, 70, 72], 90, 85),
    ("Balu", [35, 42, 38], 68, 70),
    ("Charan", [48, 55, 46], 82, 75),
    ("Divya", [60, 62, 58], 60, 65),
]

print("ACADEMIC RISK REPORT")
for name, marks, attendance, lab_score in students:
    average = sum(marks) / len(marks)
    if attendance < 65 or average < 40 or lab_score < 40:
        risk = "HIGH"
    elif attendance < 75 or average < 50 or lab_score < 50:
        risk = "MEDIUM"
    else:
        risk = "LOW"
    print(f"{name}: Average={average:.2f}, Attendance={attendance}%, Lab={lab_score}, Risk={risk}")
