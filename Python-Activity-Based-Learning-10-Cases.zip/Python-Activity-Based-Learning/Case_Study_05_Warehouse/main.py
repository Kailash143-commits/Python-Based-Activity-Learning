# Case Study 5: Warehouse Inventory Reconciliation
# Expected closing stock = opening stock + received - dispatched.

products = [
    ("Keyboard", 50, 20, 45, 23),
    ("Mouse", 80, 15, 30, 60),
    ("Monitor", 25, 10, 12, 23),
]

print("WAREHOUSE RECONCILIATION")
for name, opening, received, dispatched, actual_closing in products:
    expected = opening + received - dispatched
    difference = actual_closing - expected
    print(f"{name}: Expected={expected}, Actual={actual_closing}, Difference={difference}")
    if difference < 0:
        print(f"  Discrepancy: shortage of {-difference} units")
    elif difference > 0:
        print(f"  Discrepancy: surplus of {difference} units")
    else:
        print("  Stock reconciled.")
