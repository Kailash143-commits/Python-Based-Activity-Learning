# Case Study 7: Student Marks Matrix Analysis
# Rows are students; columns are subjects: Python, Maths, Physics.

names = ["Asha", "Balu", "Charan"]
subjects = ["Python", "Maths", "Physics"]
marks = [
    [85, 78, 90],
    [72, 88, 81],
    [91, 93, 89],
]

print("STUDENT TOTALS AND AVERAGES")
totals = []
for i in range(len(marks)):
    total = sum(marks[i])
    average = total / len(subjects)
    totals.append(total)
    print(f"{names[i]}: Total={total}, Average={average:.2f}")

print("\nSUBJECT AVERAGES")
for j in range(len(subjects)):
    total = 0
    for i in range(len(marks)):
        total += marks[i][j]
    print(f"{subjects[j]}: {total / len(marks):.2f}")

top_index = totals.index(max(totals))
print(f"Top student: {names[top_index]} with {totals[top_index]} marks")
