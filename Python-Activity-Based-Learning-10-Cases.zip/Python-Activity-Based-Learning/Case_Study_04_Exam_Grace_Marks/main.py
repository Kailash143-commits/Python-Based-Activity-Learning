# Case Study 4: Examination Result and Grace-Mark Validation
# Sample policy: pass mark is 40 in each subject. Up to 5 grace marks may be
# added to a subject scoring 35-39, without exceeding 100.

students = [
    ("Anu", [67, 72, 38]),
    ("Bharat", [55, 39, 61]),
    ("Chitra", [80, 44, 91]),
]

PASS_MARK = 40
MAX_GRACE = 5

print("EXAMINATION RESULTS")
for name, marks in students:
    final_marks = []
    grace_used = 0

    for mark in marks:
        if PASS_MARK - MAX_GRACE <= mark < PASS_MARK:
            add = min(MAX_GRACE, PASS_MARK - mark, 100 - mark)
            mark += add
            grace_used += add
        final_marks.append(mark)

    result = "PASS" if all(mark >= PASS_MARK for mark in final_marks) else "FAIL"
    print(f"{name}: Final marks = {final_marks}, Grace used = {grace_used}, Result = {result}")
