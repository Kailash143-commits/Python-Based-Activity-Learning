# Case Study 2: Progressive Electricity Billing
# Sample tariff: first 100 units Rs.1.50/unit; next 100 Rs.2.50/unit;
# above 200 Rs.4/unit; fixed charge Rs.50.

months = [("August", 145), ("September", 178), ("October", 235)]
previous_units = None

print("MONTHLY ELECTRICITY BILL")
for month, units in months:
    if units <= 100:
        energy_charge = units * 1.50
    elif units <= 200:
        energy_charge = 100 * 1.50 + (units - 100) * 2.50
    else:
        energy_charge = 100 * 1.50 + 100 * 2.50 + (units - 200) * 4.00

    total = energy_charge + 50
    print(f"{month}: {units} units, Bill = Rs.{total:.2f}")

    if previous_units is not None:
        increase = units - previous_units
        if increase > 30:
            print(f"  Alert: usage increased by {increase} units.")
    previous_units = units
