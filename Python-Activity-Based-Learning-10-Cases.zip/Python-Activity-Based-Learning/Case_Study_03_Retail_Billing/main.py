# Case Study 3: Retail Billing with Multiple Discount Rules
# Sample policy: 10% discount if subtotal >= Rs.1000; maximum discount Rs.200.
# Tax is applied after discount: 5% on all items for this example.

items = [("Notebook", 80, 5), ("Bag", 650, 1), ("Pen", 20, 10)]
subtotal = 0

print("ITEMIZED INVOICE")
for name, price, quantity in items:
    amount = price * quantity
    subtotal += amount
    print(f"{name}: {quantity} x Rs.{price} = Rs.{amount:.2f}")

discount = min(subtotal * 0.10, 200) if subtotal >= 1000 else 0
taxable_amount = subtotal - discount
tax = taxable_amount * 0.05
total = taxable_amount + tax

print(f"Subtotal: Rs.{subtotal:.2f}")
print(f"Discount: Rs.{discount:.2f}")
print(f"Tax (5%): Rs.{tax:.2f}")
print(f"Final total: Rs.{total:.2f}")
