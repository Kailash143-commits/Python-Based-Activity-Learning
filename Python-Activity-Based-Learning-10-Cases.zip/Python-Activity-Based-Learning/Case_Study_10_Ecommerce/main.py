# Case Study 10: Integrated E-Commerce Order Processing and Reconciliation
# Each order: (order_id, product, ordered_qty, dispatched_qty, returned_qty, unit_price)

orders = [
    ("O101", "Headphones", 5, 5, 1, 800),
    ("O102", "Keyboard", 8, 6, 0, 650),
    ("O103", "Mouse", 10, 10, 2, 400),
]

total_revenue = 0
print("ORDER RECONCILIATION")
for order_id, product, ordered, dispatched, returned, price in orders:
    outstanding = ordered - dispatched
    if outstanding < 0:
        print(f"{order_id}: Invalid record - dispatched quantity exceeds ordered quantity")
        continue
    net_sold = dispatched - returned
    if returned > dispatched:
        print(f"{order_id}: Invalid record - returns exceed dispatch")
        continue
    revenue = net_sold * price
    total_revenue += revenue
    print(f"{order_id} {product}: Outstanding={outstanding}, Net sold={net_sold}, Revenue=Rs.{revenue}")

print(f"Total revenue after returns: Rs.{total_revenue}")
